/* ============================================
   SRI PADA — ANIMATIONS (scroll reveal, text split, page transitions)
   Runs only when <html> has class "anim".
   ============================================ */
(function () {
  var root = document.documentElement;
  window.spjAnimReady = true;
  if (!root.classList.contains('anim')) return;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* what animates in as you scroll — [selector, style, stagger children?] */
  var TARGETS = [
    ['.section-title, .sbs-title, .featured-title, .coll-title, .cart-title, .wish-head h1, .contact-title, .pdp-title', 'up'],
    ['.featured-sub, .reviews-sub, .cat-label, .coll-desc, .contact-sub, .occ-mobile-intro', 'up'],
    ['.prod-grid > .prod-card', 'up', true],
    ['.sbs-track > .sbs-card', 'up', true],
    ['.trust-grid > .trust-item', 'up', true],
    ['.review-grid > .review-card', 'up', true],
    ['.blog-grid > .blog-card', 'up', true],
    ['.cat-grid > .cat-card', 'zoom', true],
    ['.coll-list > .coll-tile', 'up', true],
    ['.occ-cards > .occ-card', 'up', true],
    ['.tabs-nav, .view-all, .reviews-cta, .blogs-cta, .book-controls', 'up'],
    ['.book-scene', 'fade'],
    ['.contact-info > .contact-card', 'up', true],
    ['.contact-form-wrap, .cart-summary, .pin-check, .pdp-gallery', 'up'],
    ['.footer-grid > div', 'up', true],
    ['.brand-banner-overlay .brand-eyebrow, .brand-banner-overlay .btn', 'up']
  ];
  /* headings that reveal word by word */
  var SPLIT = '.hero-title, .brand-title, .pg-cover-title, .err-page h1';

  /* ---- split a heading into word spans (keeps the text readable to screen readers) ---- */
  function splitWords(el) {
    if (el.dataset.split) return;
    el.dataset.split = '1';
    var i = 0;
    (function walk(node) {
      [].slice.call(node.childNodes).forEach(function (n) {
        if (n.nodeType === 3) {
          var parts = n.textContent.split(/(\s+)/);
          var frag = document.createDocumentFragment();
          parts.forEach(function (p) {
            if (!p) return;
            if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(p)); return; }
            var w = document.createElement('span'); w.className = 'w';
            var inner = document.createElement('span'); inner.textContent = p;
            inner.style.setProperty('--wi', i++);
            w.appendChild(inner); frag.appendChild(w);
          });
          n.parentNode.replaceChild(frag, n);
        } else if (n.nodeType === 1 && !n.classList.contains('w')) {
          walk(n);
        }
      });
    })(el);
    el.classList.add('split-words');
  }

  var io = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      e.target.classList.add('is-in');
      io.unobserve(e.target);
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.12 }) : null;

  function show(el) { el.classList.add('is-in'); }

  var rowIO = io ? new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      [].slice.call(e.target.children).forEach(function (c, i) {
        if (!c.hasAttribute('data-reveal')) return;
        c.style.setProperty('--reveal-delay', (Math.min(i, 4) * 0.08) + 's');
        show(c);
      });
      rowIO.unobserve(e.target);
    });
  }, { threshold: 0.15 }) : null;

  /* catch-up: anything already scrolled past (fast scroll, jump links) is shown */
  var catchRaf;
  window.addEventListener('scroll', function () {
    cancelAnimationFrame(catchRaf);
    catchRaf = requestAnimationFrame(function () {
      var vh = window.innerHeight;
      document.querySelectorAll('[data-reveal]:not(.is-in)').forEach(function (el) {
        var r = el.getBoundingClientRect();
        if (r.bottom < 0 || (r.top < vh && r.left < window.innerWidth && r.right > 0)) show(el);
      });
    });
  }, { passive: true });

  function setup(scope) {
    scope = scope || document;
    TARGETS.forEach(function (t) {
      var els = scope.querySelectorAll(t[0]);
      var counters = new Map();
      els.forEach(function (el) {
        if (el.hasAttribute('data-reveal') || el.closest('.mobile-nav, .cart-drawer, .pin-modal, .hero-slide')) return;
        el.setAttribute('data-reveal', t[1]);
        if (t[2]) {
          var p = el.parentNode, n = counters.get(p) || 0;
          counters.set(p, n + 1);
          el.style.setProperty('--reveal-delay', (Math.min(n, 7) * 0.08) + 's');
        }
        if (reduce || !io) { show(el); return; }
        /* cards inside a swipeable row: reveal the whole row together when it scrolls into view,
           so fast swipes can't skip a card */
        var row = el.parentNode;
        if (row.matches && row.matches('.sbs-track, .occ-cards, .tabs-nav')) {
          if (!row.dataset.revealRow) { row.dataset.revealRow = '1'; rowIO.observe(row); }
          return;
        }
        io.observe(el);
      });
    });
    scope.querySelectorAll(SPLIT).forEach(function (el) {
      splitWords(el);
      if (el.closest('.hero-slide')) return;      /* hero titles play with their slide */
      if (reduce || !io) show(el); else io.observe(el);
    });
    /* hero: first slide plays immediately */
    var firstSlide = scope.querySelector('.hero-slide');
    if (firstSlide && !scope.querySelector('.hero-slide.is-active')) activateSlide(firstSlide);
  }

  function activateSlide(slide) {
    document.querySelectorAll('.hero-slide.is-active').forEach(function (s) {
      if (s === slide) return;
      s.classList.remove('is-active');
      var t = s.querySelector('.split-words'); if (t) t.classList.remove('is-in');
    });
    /* restart: remove + force reflow + add */
    slide.classList.remove('is-active');
    var title = slide.querySelector('.split-words');
    if (title) title.classList.remove('is-in');
    void slide.offsetWidth;
    slide.classList.add('is-active');
    if (title) title.classList.add('is-in');
  }
  window.spjActivateSlide = activateSlide;

  /* fade product images in as they load */
  function watchImages(scope) {
    (scope || document).querySelectorAll('.prod-img-wrap img').forEach(function (img) {
      if (img.complete) return;
      img.classList.add('is-loading');
      img.addEventListener('load', function () { img.classList.remove('is-loading'); }, { once: true });
      img.addEventListener('error', function () { img.classList.remove('is-loading'); }, { once: true });
    });
  }

  /* badge pop when cart / wishlist count changes */
  function watchBadges() {
    if (!('MutationObserver' in window)) return;
    ['cart-count', 'wish-count'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      new MutationObserver(function () {
        el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop');
      }).observe(el, { childList: true, characterData: true, subtree: true });
    });
  }
  /* heart beat on wishlist taps */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.wish-btn, .pdp-wish');
    if (!b) return;
    b.classList.remove('beat'); void b.offsetWidth; b.classList.add('beat');
  });

  /* ---- page leave fade for browsers without cross-document view transitions ---- */
  var hasVT = 'onpagereveal' in window || (window.CSS && CSS.supports && CSS.supports('view-transition-name: a'));
  if (!root.classList.contains('no-page-transitions') && !hasVT && !reduce) {
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (a.target && a.target !== '_self') return;
      if (a.hasAttribute('download') || a.getAttribute('href').charAt(0) === '#') return;
      var url; try { url = new URL(a.href, location.href); } catch (x) { return; }
      if (url.origin !== location.origin || (url.pathname === location.pathname && url.hash)) return;
      if (/^(mailto|tel|javascript):/.test(a.getAttribute('href'))) return;
      e.preventDefault();
      root.classList.add('is-leaving');
      setTimeout(function () { location.href = url.href; }, 200);
    });
    /* coming back with the browser Back button: undo the fade */
    window.addEventListener('pageshow', function (ev) { if (ev.persisted) root.classList.remove('is-leaving'); });
  }

  function init() { setup(document); watchImages(document); watchBadges(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  /* theme editor: re-run when a section is added or changed */
  document.addEventListener('shopify:section:load', function (e) { setup(e.target); watchImages(e.target); });
})();
