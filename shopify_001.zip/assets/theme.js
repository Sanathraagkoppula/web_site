/* ============================================
   SRI PADA JEWELLERS — theme.js
   ============================================ */

/* ---- HERO SLIDER (autoplay + touch swipe) ---- */
(function () {
  var track = document.getElementById('heroTrack');
  if (!track) return;
  var slides = track.querySelectorAll('.hero-slide');
  var dots = document.querySelectorAll('.hero-dot');
  var idx = 0, timer = null;

  window.heroGo = function (i) {
    idx = (i + slides.length) % slides.length;
    track.style.transform = 'translateX(-' + (idx * 100) + '%)';
    dots.forEach(function (d, n) { d.classList.toggle('on', n === idx); d.setAttribute('aria-current', n === idx ? 'true' : 'false'); });
    restart();
  };
  function restart() {
    if (timer) clearInterval(timer);
    if (slides.length > 1 && !document.hidden) timer = setInterval(function () { window.heroGo(idx + 1); }, 6500);
  }
  document.addEventListener('visibilitychange', restart);
  restart();

  var x0 = null, y0 = null;
  track.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
  track.addEventListener('touchend', function (e) {
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) window.heroGo(idx + (dx < 0 ? 1 : -1));
    x0 = null;
  }, { passive: true });
})();

/* ---- MOBILE NAV ---- */
function openMobileNav() {
  document.getElementById('mNav').classList.add('open');
  document.getElementById('mNavBackdrop').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeMobileNav() {
  document.getElementById('mNav').classList.remove('open');
  document.getElementById('mNavBackdrop').classList.remove('open');
  document.body.style.overflow = '';
}

/* ============================================
   CART DRAWER (AJAX)
   ============================================ */
function money(cents) {
  return '₹' + (cents / 100).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function openCartDrawer(e) {
  if (e) e.preventDefault();
  document.getElementById('cartDrawer').classList.add('open');
  document.getElementById('cartBackdrop').classList.add('open');
  document.body.style.overflow = 'hidden';
  refreshCartDrawer();
  return false;
}
function closeCartDrawer() {
  document.getElementById('cartDrawer').classList.remove('open');
  document.getElementById('cartBackdrop').classList.remove('open');
  document.body.style.overflow = '';
}

function updateCartCount(count) {
  ['cart-count', 'drawer-count'].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    if (id === 'cart-count') el.style.display = count > 0 ? 'flex' : 'none';
  });
}

function refreshCartDrawer() {
  var body = document.getElementById('drawer-body');
  var foot = document.getElementById('drawer-foot');
  if (!body) return;
  body.innerHTML = '<p class="drawer-empty">Loading…</p>';

  fetch('/cart.js', { headers: { 'Accept': 'application/json' } })
    .then(function (r) { return r.json(); })
    .then(function (cart) {
      updateCartCount(cart.item_count);
      if (!cart.item_count) {
        body.innerHTML = '<p class="drawer-empty">Your bag is empty.</p>';
        foot.style.display = 'none';
        return;
      }
      body.innerHTML = cart.items.map(function (it) {
        var img = it.image
          ? '<img src="' + it.image + '" alt="">'
          : '💍';
        var variant = (it.variant_title && it.variant_title.indexOf('Default') === -1)
          ? '<div class="drawer-item-meta">' + it.variant_title + '</div>' : '';
        return '' +
          '<div class="drawer-item">' +
            '<div class="drawer-item-img">' + img + '</div>' +
            '<div>' +
              '<div class="drawer-item-name">' + it.product_title + '</div>' +
              variant +
              '<div class="drawer-item-meta">Qty ' + it.quantity + '</div>' +
              '<span class="drawer-item-remove" onclick="drawerRemove(\'' + it.key + '\')">Remove</span>' +
            '</div>' +
            '<div class="drawer-item-price">' + money(it.final_line_price) + '</div>' +
          '</div>';
      }).join('');
      document.getElementById('drawer-subtotal').textContent = money(cart.items_subtotal_price);
      foot.style.display = 'block';
    })
    .catch(function () { body.innerHTML = '<p class="drawer-empty">Could not load bag.</p>'; });
}

function drawerRemove(key) {
  fetch('/cart/change.js', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({ id: key, quantity: 0 })
  }).then(function (r) { return r.json(); })
    .then(function (cart) { updateCartCount(cart.item_count); refreshCartDrawer(); });
}

/* intercept add-to-bag forms → AJAX add → open drawer */
document.addEventListener('submit', function (e) {
  var form = e.target;
  var isAdd = form.classList.contains('add-to-bag-form') ||
              (form.getAttribute('action') || '').indexOf('/cart/add') > -1;
  if (!isAdd) return;
  // let the product form's own submit still work if JS fails — but prefer AJAX
  e.preventDefault();
  var data = new FormData(form);
  fetch('/cart/add.js', { method: 'POST', body: data, headers: { 'Accept': 'application/json' } })
    .then(function (r) { return r.json(); })
    .then(function () { openCartDrawer(); })
    .catch(function () { form.submit(); });
});

/* ============================================
   WISHLIST  (client-side, saved per browser)
   ============================================ */
var wishlist = [];
try { wishlist = JSON.parse(localStorage.getItem('spj_wishlist')) || []; } catch (e) { wishlist = []; }

function wishSave() {
  try { localStorage.setItem('spj_wishlist', JSON.stringify(wishlist)); } catch (e) {}
}

function wishToggle(e, btn) {
  e.preventDefault();
  e.stopPropagation();
  var item = {
    id: btn.dataset.pid, name: btn.dataset.name, price: btn.dataset.price,
    url: btn.dataset.url, img: btn.dataset.img || ''
  };
  var i = wishlist.findIndex(function (w) { return w.id === item.id; });
  if (i > -1) { wishlist.splice(i, 1); } else { wishlist.push(item); }
  wishSave();
  syncHearts();
  renderWishlist();
}

function wishRemove(id) {
  wishlist = wishlist.filter(function (w) { return w.id !== id; });
  wishSave();
  syncHearts();
  renderWishlist();
}

function syncHearts() {
  document.querySelectorAll('.wish-btn').forEach(function (btn) {
    var on = wishlist.some(function (w) { return w.id === btn.dataset.pid; });
    btn.textContent = on ? '♥' : '♡';
    btn.style.color = on ? '#C6A24E' : '';
    btn.classList.toggle('active', on);
  });
  var badge = document.getElementById('wish-count');
  if (badge) {
    badge.textContent = wishlist.length;
    badge.style.display = wishlist.length ? 'flex' : 'none';
  }
}

function renderWishlist() {
  var grid = document.getElementById('wish-grid');
  if (!grid) return;
  var empty = document.getElementById('wish-empty');
  if (!wishlist.length) {
    grid.innerHTML = '';
    grid.style.display = 'none';
    if (empty) empty.style.display = 'block';
    return;
  }
  if (empty) empty.style.display = 'none';
  grid.style.display = 'grid';
  grid.innerHTML = wishlist.map(function (w) {
    var media = w.img
      ? '<img src="' + w.img + '" style="width:100%;height:100%;object-fit:cover;">'
      : '<div class="emoji-placeholder">💍</div>';
    return '' +
      '<div class="prod-card">' +
        '<a href="' + w.url + '" class="prod-img-wrap" style="display:block;">' + media +
          '<div class="wish-remove" title="Remove" onclick="event.preventDefault();wishRemove(\'' + w.id + '\')">×</div>' +
        '</a>' +
        '<a href="' + w.url + '" class="prod-info" style="display:block;text-decoration:none;">' +
          '<div class="prod-name">' + w.name + '</div>' +
          '<div class="prod-pricing"><span class="prod-price">' + w.price + '</span></div>' +
        '</a>' +
      '</div>';
  }).join('');
}

document.addEventListener('DOMContentLoaded', function () {
  syncHearts();
  renderWishlist();
});

/* ============================================
   LOCATION / PINCODE PICKER  (saved per browser)
   ============================================ */
(function () {
  var KEY = 'spj_pincode';

  function setLabel(pin) {
    var el = document.getElementById('pincodeLabel');
    if (!el) return;
    el.textContent = pin ? pin : (el.dataset.empty || 'Enter Pincode');
  }

  function serviceable() {
    var m = document.getElementById('pinModal');
    if (!m) return [];
    return (m.dataset.serviceable || '')
      .split(',').map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function saved() {
    try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; }
  }

  window.openPincode = function () {
    var m = document.getElementById('pinModal');
    var b = document.getElementById('pinBackdrop');
    if (!m || !b) return;
    m.classList.add('open');
    b.classList.add('open');
    document.body.style.overflow = 'hidden';
    var input = document.getElementById('pinInput');
    var msg = document.getElementById('pinMsg');
    if (msg) { msg.className = 'pin-msg'; msg.textContent = ''; }
    if (input) {
      input.value = saved();
      setTimeout(function () { input.focus(); }, 60);
    }
  };

  window.closePincode = function () {
    var m = document.getElementById('pinModal');
    var b = document.getElementById('pinBackdrop');
    if (m) m.classList.remove('open');
    if (b) b.classList.remove('open');
    document.body.style.overflow = '';
  };

  function check(pin) {
    var msg = document.getElementById('pinMsg');
    if (!/^[0-9]{6}$/.test(pin)) {
      if (msg) { msg.className = 'pin-msg err'; msg.textContent = 'Please enter a valid 6-digit pincode.'; }
      return false;
    }

    try { localStorage.setItem(KEY, pin); } catch (e) {}
    setLabel(pin);

    var list = serviceable();
    var ok = !list.length || list.indexOf(pin) > -1;

    if (msg) {
      if (ok) {
        msg.className = 'pin-msg ok';
        msg.innerHTML = '&#10003; Delivering to <b>' + pin + '</b> &mdash; estimated 3&ndash;5 days.';
      } else {
        msg.className = 'pin-msg err';
        msg.innerHTML = 'We don\'t deliver to <b>' + pin + '</b> yet &mdash; saved, we\'ll notify you.';
      }
    }
    setTimeout(window.closePincode, 1200);
    return ok;
  }

  window.pickPincode = function (pin) {
    var input = document.getElementById('pinInput');
    if (input) input.value = pin;
    check(pin);
  };

  window.savePincode = function (e) {
    e.preventDefault();
    var input = document.getElementById('pinInput');
    check(input ? input.value.trim() : '');
    return false;
  };

  document.addEventListener('DOMContentLoaded', function () {
    var pin = saved();
    if (pin) setLabel(pin);
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') window.closePincode();
  });
})();

/* ============================================
   PRODUCT TABS
   ============================================ */
function switchTab(btn, panelId) {
  var section = btn.closest('.tabbed');
  if (!section) return;
  section.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('on'); });
  section.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('on'); });
  btn.classList.add('on');
  var panel = document.getElementById(panelId);
  if (panel) panel.classList.add('on');
}

/* ============================================
   OCCASIONS FLIP-BOOK  (supports multiple instances)
   ============================================ */
(function () {
  function render(book) {
    var scene = book.closest('.book-scene');
    var section = book.closest('.occasions');
    var leaves = [].slice.call(book.querySelectorAll('.leaf'));
    var LEAVES = leaves.length;
    var flip = parseInt(book.dataset.flip || '0', 10);
    var open = flip >= 1;

    book.classList.toggle('open', open);
    if (scene) scene.classList.toggle('is-open', open);

    leaves.forEach(function (leaf, i) {
      var flipped = i < flip;
      leaf.classList.toggle('flipped', flipped);
      leaf.style.zIndex = flipped ? 100 + i : 50 - i;
    });

    var prev = section.querySelector('[data-book-prev]');
    var next = section.querySelector('[data-book-next]');
    var prog = section.querySelector('[data-book-progress]');
    if (prev) prev.disabled = flip === 0;
    if (next) next.disabled = flip === LEAVES;
    if (prog) {
      if (flip === 0) { prog.textContent = 'Tap to open'; }
      else {
        var active = leaves[flip - 1];
        prog.innerHTML = active ? (active.dataset.label || ('Page ' + flip)) : ('Page ' + flip);
      }
    }
  }

  function turn(book, dir) {
    var LEAVES = book.querySelectorAll('.leaf').length;
    var flip = parseInt(book.dataset.flip || '0', 10) + dir;
    if (flip < 0 || flip > LEAVES) return;
    book.dataset.flip = flip;
    render(book);
  }

  window.bookTurn = function (btn, dir) {
    var book = btn.closest('.occasions').querySelector('[data-book]');
    if (book) turn(book, dir);
  };
  window.bookClose = function (btn) {
    var book = btn.closest('.occasions').querySelector('[data-book]');
    if (book) { book.dataset.flip = 0; render(book); }
  };

  /* scale the 720×480 book to whatever width is available */
  function fit() {
    document.querySelectorAll('.book-scene').forEach(function (scene) {
      var avail = scene.clientWidth - 24;
      var s = Math.max(.3, Math.min(1, avail / 720));
      scene.style.setProperty('--bs', s.toFixed(3));
    });
  }
  var fitRaf;
  window.addEventListener('resize', function () { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fit); });

  document.addEventListener('DOMContentLoaded', function () {
    fit();
    document.querySelectorAll('[data-book]').forEach(function (book) {
      var tx = null, ty = null;
      book.addEventListener('touchstart', function (e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
      book.addEventListener('touchend', function (e) {
        if (tx === null) return;
        var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
        if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) { book.dataset.swiped = Date.now(); turn(book, dx < 0 ? 1 : -1); }
        tx = null;
      }, { passive: true });
      book.dataset.flip = '0';
      render(book);
      book.addEventListener('click', function (e) {
        if (book.dataset.swiped && Date.now() - book.dataset.swiped < 500) return;
        if (e.target.closest('.pg-explore') || e.target.closest('.btn') || e.target.closest('a')) return;
        var flip = parseInt(book.dataset.flip || '0', 10);
        if (flip === 0) { turn(book, 1); return; }
        var spineX = book.getBoundingClientRect().left;
        turn(book, e.clientX < spineX ? -1 : 1);
      });
    });
  });
})();
