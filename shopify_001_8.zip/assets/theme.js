/* ============================================
   SRI PADA JEWELLERS — theme.js
   ============================================ */

/* ---- shared helpers ---- */
var ROOT = (window.Shopify && Shopify.routes && Shopify.routes.root) || '/';
function esc(str) {
  return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
var lastFocus = null;
function lockScroll(on) {
  document.documentElement.classList.toggle('scroll-locked', !!on);
}
function openLayer(panel, backdrop, focusSel) {
  lastFocus = document.activeElement;
  panel.classList.add('open');
  panel.setAttribute('aria-hidden', 'false');
  if (backdrop) backdrop.classList.add('open');
  lockScroll(true);
  var f = focusSel ? panel.querySelector(focusSel) : panel.querySelector('button, a, input');
  if (f) setTimeout(function () { try { f.focus({ preventScroll: true }); } catch (e) { f.focus(); } }, 80);
}
function closeLayer(panel, backdrop) {
  if (!panel || !panel.classList.contains('open')) return;
  panel.classList.remove('open');
  panel.setAttribute('aria-hidden', 'true');
  if (backdrop) backdrop.classList.remove('open');
  if (!document.querySelector('.mobile-nav.open, .cart-drawer.open, .pin-modal.open')) lockScroll(false);
  if (lastFocus && lastFocus.focus) { try { lastFocus.focus({ preventScroll: true }); } catch (e) {} }
}

/* ---- HERO SLIDER (autoplay + touch swipe) ---- */
(function () {
  var track = document.getElementById('heroTrack');
  if (!track) return;
  var slides = track.querySelectorAll('.hero-slide');
  var dots = document.querySelectorAll('.hero-dot');
  var idx = 0, timer = null;
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var paused = false;

  function setInert() {
    slides.forEach(function (sl, n) {
      var hidden = n !== idx;
      sl.setAttribute('aria-hidden', hidden ? 'true' : 'false');
      if ('inert' in sl) sl.inert = hidden;
    });
  }
  window.heroGo = function (i) {
    idx = (i + slides.length) % slides.length;
    track.style.transform = 'translateX(-' + (idx * 100) + '%)';
    dots.forEach(function (d, n) { d.classList.toggle('on', n === idx); d.setAttribute('aria-current', n === idx ? 'true' : 'false'); });
    setInert();
    restart();
  };
  function restart() {
    if (timer) clearInterval(timer);
    if (slides.length > 1 && !document.hidden && !reduce && !paused) timer = setInterval(function () { window.heroGo(idx + 1); }, 6500);
  }
  var wrap = track.closest('.hero-wrap');
  if (wrap) {
    wrap.addEventListener('mouseenter', function () { paused = true; restart(); });
    wrap.addEventListener('mouseleave', function () { paused = false; restart(); });
    wrap.addEventListener('focusin', function () { paused = true; restart(); });
    wrap.addEventListener('focusout', function () { paused = false; restart(); });
  }
  document.addEventListener('visibilitychange', restart);
  setInert();
  restart();

  var x0 = null, y0 = null;
  track.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; }, { passive: true });
  track.addEventListener('touchend', function (e) {
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) window.heroGo(idx + (dx < 0 ? 1 : -1));
    x0 = null;
  }, { passive: true });
})();

/* ---- MOBILE NAV ---- */
function setNavExpanded(v) {
  document.querySelectorAll('.nav-toggle').forEach(function (b) { b.setAttribute('aria-expanded', v ? 'true' : 'false'); });
}
function openMobileNav() {
  openLayer(document.getElementById('mNav'), document.getElementById('mNavBackdrop'), '.mobile-nav-close');
  setNavExpanded(true);
}
function closeMobileNav() {
  closeLayer(document.getElementById('mNav'), document.getElementById('mNavBackdrop'));
  setNavExpanded(false);
}

/* ============================================
   CART DRAWER (AJAX)
   ============================================ */
function money(cents) {
  return '₹' + (cents / 100).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function openCartDrawer(e) {
  if (e) e.preventDefault();
  openLayer(document.getElementById('cartDrawer'), document.getElementById('cartBackdrop'), '.drawer-close');
  refreshCartDrawer();
  return false;
}
function closeCartDrawer() {
  closeLayer(document.getElementById('cartDrawer'), document.getElementById('cartBackdrop'));
}

function updateCartCount(count) {
  ['cart-count', 'drawer-count'].forEach(function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    if (id === 'cart-count') el.style.display = count > 0 ? 'flex' : 'none';
  });
}

function sizedImg(url, w) {
  if (!url) return '';
  return url + (url.indexOf('?') > -1 ? '&' : '?') + 'width=' + w;
}

function refreshCartDrawer() {
  var body = document.getElementById('drawer-body');
  var foot = document.getElementById('drawer-foot');
  if (!body) return;
  if (!body.children.length) body.innerHTML = '<p class="drawer-empty">Loading…</p>';

  fetch(ROOT + 'cart.js', { headers: { 'Accept': 'application/json' } })
    .then(function (r) { return r.json(); })
    .then(function (cart) {
      updateCartCount(cart.item_count);
      if (!cart.item_count) {
        body.innerHTML = '<div class="drawer-empty"><p>Your bag is empty.</p><a class="btn btn-black" href="' + ROOT + 'collections/all">Start shopping</a></div>';
        foot.style.display = 'none';
        return;
      }
      body.innerHTML = cart.items.map(function (it, n) {
        var img = it.image
          ? '<img src="' + esc(sizedImg(it.image, 160)) + '" alt="" width="60" height="60" loading="lazy">'
          : '💍';
        var variant = (!it.product_has_only_default_variant && it.variant_title)
          ? '<div class="drawer-item-meta">' + esc(it.variant_title) + '</div>' : '';
        return '' +
          '<div class="drawer-item">' +
            '<a class="drawer-item-img" href="' + esc(it.url) + '" tabindex="-1" aria-hidden="true">' + img + '</a>' +
            '<div>' +
              '<a class="drawer-item-name" href="' + esc(it.url) + '">' + esc(it.product_title) + '</a>' +
              variant +
              '<div class="qty drawer-qty">' +
                '<button type="button" class="qty-btn" aria-label="Decrease quantity" onclick="drawerSetQty(\'' + esc(it.key) + '\',' + (it.quantity - 1) + ')">−</button>' +
                '<span class="qty-inp" aria-live="polite">' + it.quantity + '</span>' +
                '<button type="button" class="qty-btn" aria-label="Increase quantity" onclick="drawerSetQty(\'' + esc(it.key) + '\',' + (it.quantity + 1) + ')">+</button>' +
              '</div>' +
              '<button type="button" class="drawer-item-remove" onclick="drawerSetQty(\'' + esc(it.key) + '\',0)">Remove</button>' +
            '</div>' +
            '<div class="drawer-item-price">' + money(it.final_line_price) + '</div>' +
          '</div>';
      }).join('');
      document.getElementById('drawer-subtotal').textContent = money(cart.items_subtotal_price);
      foot.style.display = 'block';
    })
    .catch(function () { body.innerHTML = '<p class="drawer-empty">Could not load your bag. <a href="' + ROOT + 'cart">Open bag page</a></p>'; });
}

function drawerSetQty(key, qty) {
  var body = document.getElementById('drawer-body');
  if (body) body.classList.add('is-busy');
  fetch(ROOT + 'cart/change.js', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({ id: key, quantity: Math.max(0, qty) })
  }).then(function (r) { return r.json(); })
    .then(function (cart) { updateCartCount(cart.item_count); refreshCartDrawer(); })
    .catch(function () {})
    .then(function () { if (body) body.classList.remove('is-busy'); });
}
function drawerRemove(key) { drawerSetQty(key, 0); }

/* intercept add-to-bag forms → AJAX add → open drawer */
document.addEventListener('submit', function (e) {
  var form = e.target;
  var action = form.getAttribute('action') || '';
  var isAdd = form.classList.contains('add-to-bag-form') || /\/cart\/add(\?|$|\.js)/.test(action);
  if (!isAdd || !window.fetch || !window.FormData) return;
  e.preventDefault();
  var btn = form.querySelector('[type="submit"]');
  var msg = form.querySelector('[data-pp-msg]');
  var label = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.classList.add('is-loading'); btn.textContent = 'ADDING…'; }
  if (msg) { msg.hidden = true; msg.textContent = ''; }

  fetch(ROOT + 'cart/add.js', { method: 'POST', body: new FormData(form), headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
    .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, data: j }; }); })
    .then(function (res) {
      if (!res.ok) {
        var text = (res.data && (res.data.description || res.data.message)) || 'Could not add this item.';
        if (msg) { msg.textContent = text; msg.hidden = false; } else { alert(text); }
        return;
      }
      openCartDrawer();
    })
    .catch(function () { form.submit(); })
    .then(function () { if (btn) { btn.disabled = false; btn.classList.remove('is-loading'); btn.textContent = label; } });
});

/* ============================================
   WISHLIST  (client-side, saved per browser)
   ============================================ */
var wishlist = [];
try { wishlist = JSON.parse(localStorage.getItem('spj_wishlist')) || []; } catch (e) { wishlist = []; }

function wishSave() {
  try { localStorage.setItem('spj_wishlist', JSON.stringify(wishlist)); } catch (e) {}
}

function wishToggle(e, btn) {
  e.preventDefault();
  e.stopPropagation();
  var item = {
    id: btn.dataset.pid, name: btn.dataset.name, price: btn.dataset.price,
    url: btn.dataset.url, img: btn.dataset.img || ''
  };
  var i = wishlist.findIndex(function (w) { return w.id === item.id; });
  if (i > -1) { wishlist.splice(i, 1); } else { wishlist.push(item); }
  wishSave();
  syncHearts();
  renderWishlist();
}

function wishRemove(id) {
  wishlist = wishlist.filter(function (w) { return w.id !== id; });
  wishSave();
  syncHearts();
  renderWishlist();
}

function syncHearts() {
  document.querySelectorAll('.wish-btn').forEach(function (btn) {
    var on = wishlist.some(function (w) { return w.id === btn.dataset.pid; });
    btn.textContent = on ? '♥' : '♡';
    btn.classList.toggle('active', on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  });
  var badge = document.getElementById('wish-count');
  if (badge) {
    badge.textContent = wishlist.length;
    badge.style.display = wishlist.length ? 'flex' : 'none';
  }
}

function renderWishlist() {
  var grid = document.getElementById('wish-grid');
  if (!grid) return;
  var empty = document.getElementById('wish-empty');
  if (!wishlist.length) {
    grid.innerHTML = '';
    grid.style.display = 'none';
    if (empty) empty.style.display = 'block';
    return;
  }
  if (empty) empty.style.display = 'none';
  grid.style.display = 'grid';
  grid.innerHTML = wishlist.map(function (w) {
    var media = w.img
      ? '<img src="' + esc(w.img) + '" alt="' + esc(w.name) + '" loading="lazy" width="300" height="300">'
      : '<div class="emoji-placeholder">💍</div>';
    return '' +
      '<div class="prod-card">' +
        '<a href="' + esc(w.url) + '" class="prod-img-wrap">' + media + '</a>' +
        '<button type="button" class="wish-remove" aria-label="Remove ' + esc(w.name) + ' from wishlist" onclick="wishRemove(\'' + esc(w.id) + '\')">×</button>' +
        '<a href="' + esc(w.url) + '" class="prod-info">' +
          '<div class="prod-name">' + esc(w.name) + '</div>' +
          '<div class="prod-pricing"><span class="prod-price">' + esc(w.price) + '</span></div>' +
        '</a>' +
        '<a href="' + esc(w.url) + '" class="add-btn wish-view">VIEW PRODUCT</a>' +
      '</div>';
  }).join('');
}

document.addEventListener('DOMContentLoaded', function () {
  syncHearts();
  renderWishlist();
});

/* ============================================
   LOCATION / PINCODE PICKER  (saved per browser)
   ============================================ */
(function () {
  var KEY = 'spj_pincode';

  function setLabel(pin) {
    var el = document.getElementById('pincodeLabel');
    if (!el) return;
    el.textContent = pin ? pin : (el.dataset.empty || 'Enter Pincode');
  }

  function serviceable() {
    var m = document.getElementById('pinModal');
    if (!m) return [];
    return (m.dataset.serviceable || '')
      .split(',').map(function (s) { return s.trim(); }).filter(Boolean);
  }

  function saved() {
    try { return localStorage.getItem(KEY) || ''; } catch (e) { return ''; }
  }

  window.openPincode = function () {
    var m = document.getElementById('pinModal');
    var b = document.getElementById('pinBackdrop');
    if (!m || !b) return;
    var input = document.getElementById('pinInput');
    var msg = document.getElementById('pinMsg');
    if (msg) { msg.className = 'pin-msg'; msg.textContent = ''; }
    if (input) input.value = saved();
    openLayer(m, b, '#pinInput');
  };

  window.closePincode = function () {
    closeLayer(document.getElementById('pinModal'), document.getElementById('pinBackdrop'));
  };

  function check(pin) {
    var msg = document.getElementById('pinMsg');
    if (!/^[0-9]{6}$/.test(pin)) {
      if (msg) { msg.className = 'pin-msg err'; msg.textContent = 'Please enter a valid 6-digit pincode.'; }
      return false;
    }

    try { localStorage.setItem(KEY, pin); } catch (e) {}
    setLabel(pin);

    var list = serviceable();
    var ok = !list.length || list.indexOf(pin) > -1;

    if (msg) {
      if (ok) {
        msg.className = 'pin-msg ok';
        msg.innerHTML = '&#10003; Delivering to <b>' + esc(pin) + '</b> &mdash; estimated 3&ndash;5 days.';
      } else {
        msg.className = 'pin-msg err';
        msg.innerHTML = 'We don\'t deliver to <b>' + esc(pin) + '</b> yet. Contact us and we\'ll try to help.';
      }
    }
    if (ok) setTimeout(window.closePincode, 1400);
    return ok;
  }

  window.pickPincode = function (pin) {
    var input = document.getElementById('pinInput');
    if (input) input.value = pin;
    check(pin);
  };

  window.savePincode = function (e) {
    e.preventDefault();
    var input = document.getElementById('pinInput');
    check(input ? input.value.trim() : '');
    return false;
  };

  document.addEventListener('DOMContentLoaded', function () {
    var pin = saved();
    if (pin) setLabel(pin);
  });

  var pinInput = document.getElementById('pinInput');
  if (pinInput) pinInput.addEventListener('input', function () { this.value = this.value.replace(/\D/g, '').slice(0, 6); });
})();

/* ============================================
   PRODUCT TABS
   ============================================ */
function switchTab(btn, panelId) {
  var section = btn.closest('.tabbed');
  if (!section) return;
  section.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('on'); b.setAttribute('aria-selected', 'false'); b.setAttribute('tabindex', '-1'); });
  section.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('on'); });
  btn.classList.add('on');
  btn.setAttribute('aria-selected', 'true');
  btn.removeAttribute('tabindex');
  if (btn.scrollIntoView && btn.parentNode.scrollWidth > btn.parentNode.clientWidth) {
    try { btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' }); } catch (e) {}
  }
  var panel = document.getElementById(panelId);
  if (panel) panel.classList.add('on');
}
/* arrow-key navigation between tabs */
document.addEventListener('keydown', function (e) {
  var t = e.target;
  if (!t.classList || !t.classList.contains('tab-btn')) return;
  if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
  var tabs = [].slice.call(t.parentNode.querySelectorAll('.tab-btn'));
  var n = tabs.indexOf(t) + (e.key === 'ArrowRight' ? 1 : -1);
  var next = tabs[(n + tabs.length) % tabs.length];
  next.focus(); next.click();
  e.preventDefault();
});

/* ============================================
   OCCASIONS FLIP-BOOK  (supports multiple instances)
   ============================================ */
(function () {
  function render(book) {
    var scene = book.closest('.book-scene');
    var section = book.closest('.occasions');
    var leaves = [].slice.call(book.querySelectorAll('.leaf'));
    var LEAVES = leaves.length;
    var flip = parseInt(book.dataset.flip || '0', 10);
    var open = flip >= 1;

    book.classList.toggle('open', open);
    if (scene) scene.classList.toggle('is-open', open);

    leaves.forEach(function (leaf, i) {
      var flipped = i < flip;
      leaf.classList.toggle('flipped', flipped);
      leaf.style.zIndex = flipped ? 100 + i : 50 - i;
    });

    var prev = section.querySelector('[data-book-prev]');
    var next = section.querySelector('[data-book-next]');
    var prog = section.querySelector('[data-book-progress]');
    if (prev) prev.disabled = flip === 0;
    if (next) next.disabled = flip === LEAVES;
    if (prog) {
      if (flip === 0) { prog.textContent = 'Tap to open'; }
      else {
        /* visible spread = back of the last turned leaf (left) + front of the next leaf (right) */
        var left = leaves[flip - 1] ? leaves[flip - 1].dataset.back : '';
        var right = leaves[flip] ? leaves[flip].dataset.front : 'The End';
        prog.textContent = [left, right].filter(Boolean).join(' & ') || ('Page ' + flip);
      }
    }
  }

  function turn(book, dir) {
    var LEAVES = book.querySelectorAll('.leaf').length;
    var flip = parseInt(book.dataset.flip || '0', 10) + dir;
    if (flip < 0 || flip > LEAVES) return;
    book.dataset.flip = flip;
    render(book);
  }

  window.bookTurn = function (btn, dir) {
    var book = btn.closest('.occasions').querySelector('[data-book]');
    if (book) turn(book, dir);
  };
  window.bookClose = function (btn) {
    var book = btn.closest('.occasions').querySelector('[data-book]');
    if (book) { book.dataset.flip = 0; render(book); }
  };

  /* scale the 720×480 book to whatever width is available */
  function fit() {
    document.querySelectorAll('.book-scene').forEach(function (scene) {
      var avail = scene.clientWidth - 24;
      var s = Math.max(.3, Math.min(1, avail / 720));
      scene.style.setProperty('--bs', s.toFixed(3));
    });
  }
  var fitRaf;
  window.addEventListener('resize', function () { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fit); });

  document.addEventListener('DOMContentLoaded', function () {
    fit();
    document.querySelectorAll('[data-book]').forEach(function (book) {
      var tx = null, ty = null;
      book.addEventListener('touchstart', function (e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
      book.addEventListener('touchend', function (e) {
        if (tx === null) return;
        var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
        if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) { book.dataset.swiped = Date.now(); turn(book, dx < 0 ? 1 : -1); }
        tx = null;
      }, { passive: true });
      book.dataset.flip = '0';
      render(book);
      book.addEventListener('click', function (e) {
        if (book.dataset.swiped && Date.now() - book.dataset.swiped < 500) return;
        if (e.target.closest('.pg-explore') || e.target.closest('.btn') || e.target.closest('a')) return;
        var flip = parseInt(book.dataset.flip || '0', 10);
        if (flip === 0) { turn(book, 1); return; }
        var r = book.getBoundingClientRect();
        var spineX = r.left;
        turn(book, e.clientX < spineX ? -1 : 1);
      });
    });
  });
})();

/* ============================================
   GLOBAL: Escape closes any open layer
   ============================================ */
document.addEventListener('keydown', function (e) {
  if (e.key !== 'Escape') return;
  if (document.querySelector('.pin-modal.open')) { window.closePincode && window.closePincode(); return; }
  if (document.querySelector('.cart-drawer.open')) { closeCartDrawer(); return; }
  if (document.querySelector('.mobile-nav.open')) { closeMobileNav(); }
});
/* close the mobile menu if the screen is widened past the breakpoint */
window.addEventListener('resize', function () {
  if (window.innerWidth > 900 && document.querySelector('.mobile-nav.open')) closeMobileNav();
});

/* ============================================
   OCCASIONS — mobile card carousel dots
   ============================================ */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-occ-track]').forEach(function (track) {
    var dots = track.parentNode.querySelectorAll('.occ-dot');
    if (!dots.length) return;
    var raf;
    track.addEventListener('scroll', function () {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(function () {
        var cards = track.children, best = 0, bestD = Infinity, mid = track.scrollLeft + track.clientWidth / 2;
        for (var i = 0; i < cards.length; i++) {
          var c = cards[i], d = Math.abs(c.offsetLeft + c.offsetWidth / 2 - mid);
          if (d < bestD) { bestD = d; best = i; }
        }
        dots.forEach(function (d, i) { d.classList.toggle('on', i === best); });
      });
    }, { passive: true });
  });
});
